/*
comment this line in validator.js (\node_modules\jsonschema\lib\validator.js:111):

if((typeof schema !== 'boolean' && typeof schema !== 'object') || schema === null){
     throw new SchemaError('Expected `schema` to be an object or boolean');
}
*/

const mosca = require("mosca");
const settings = { port: 1883 };
const broker = new mosca.Server(settings);

broker.on("ready", () => {
  console.log("Broker Ready!");
});

// fired when a message is published
broker.on("published", (package, client) => {
  const topic = package.topic;
  const message = package.payload.toString();
  // console.log("Published", message);
  const chkMsg = message.slice(0, 2) !== '{"' && message.slice(0, 4) !== "mqtt";
  const data = { topic, message };
  if (chkMsg) console.log(data);
});

// fired when a client connects
broker.on("clientConnected", (client) => {
  console.log(
    "Client Connected with IP:",
    client.connection.stream.remoteAddress?.toString()?.slice(7)
  );
});

// fired when a client disconnects
broker.on("clientDisconnected", (client) => {
  console.log(
    "Client Disconnected with IP:",
    client.connection.stream.remoteAddress?.toString()?.slice(7)
  );
});
